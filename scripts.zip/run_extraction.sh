#!/bin/bash
dataset=$1 # choices=[flickr7k, senticap]
bsz=$2 # it's up to your GPU memory size
thr=$3 # extraction proportion. default thr=0.25

CUDA_VISIBLE_DEVICES=0 python -u sentiment_extraction_v1-1.py \
            --dataset $dataset \
            --threshold $thr \
            --batch_size $bsz \
            --do_select \
            --output_dir output/classifier/$dataset/ \
            --style_text_dir data/$dataset
