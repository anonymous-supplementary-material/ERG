exp=$1
style=$2
CUDA_VISIBLE_DEVICES=0 python gpt_infer.py \
    --do_eval \
    --do_multimodal \
    --mode coco \
    --style ${style} \
    --style_model_dir output/style-eval/senticap/${style} \
    --lm_model_dir output/lm-eval/senticap_${style}.srilm \
    --csv_path output/gpt_infer/${exp}/infer_v1-1_${style}_multimodal_retrieval_by_coco.csv
