exp=$1
dataset=$2
s0=$3
s1=$4
CUDA_VISIBLE_DEVICES=0 python train_gpt.py \
    --do_train \
    --do_eval \
    --log_path logs/train_gpt_${dataset}.log\
    --batch_size 64 \
    --learning_rate 5e-5 \
    --num_train_epochs 1 \
    --factual_train_text_path data/${dataset}/factual_train.txt \
    --style0_train_text_path data/${dataset}/${s0}_train.txt \
    --style1_train_text_path data/${dataset}/${s1}_train.txt \
    --style0_train_part_path output/style_extraction_v1-1/${exp}/${s0}_train_style.txt \
    --style1_train_part_path output/style_extraction_v1-1/${exp}/${s1}_train_style.txt \
    --factual_val_text_path data/${dataset}/factual_val.txt \
    --style0_val_text_path data/${dataset}/${s0}_val.txt \
    --style1_val_text_path data/${dataset}/${s1}_val.txt \
    --style0_val_part_path output/style_extraction_v1-1/${exp}/${s0}_val_style.txt \
    --style1_val_part_path output/style_extraction_v1-1/${exp}/${s1}_val_style.txt \
    --output_dir output/gpt-v1-1-${dataset}
