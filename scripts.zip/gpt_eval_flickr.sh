exp=$1
style=$2
CUDA_VISIBLE_DEVICES=0 python gpt_infer.py \
    --do_eval \
    --do_multimodal \
    --mode flickr30k \
    --style ${style} \
    --style_model_dir output/style-eval/flickr7k/${style} \
    --lm_model_dir output/lm-eval/flickr7k_${style}.srilm \
    --csv_path output/gpt_infer/${exp}/infer_v1-1_${style}_multimodal_retrieval_by_flickr30k.csv
