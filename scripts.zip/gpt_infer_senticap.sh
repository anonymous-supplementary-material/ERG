exp=$1
style=$2
CUDA_VISIBLE_DEVICES=0 python gpt_infer.py \
	--do_infer \
	--do_multimodal \
	--mode coco \
	--style ${style} \
	--output_dir output/gpt-v1-1-senticap/ \
	--csv_path output/retrieval_multimodal/${exp}/${style}_multimodal_retrieval_by_coco.csv
