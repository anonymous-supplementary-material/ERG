style=$1 # pos / neg
exp=$2 # the folder path of the style extraction results
python retrieval_multimodal.py \
	--mode coco \
	--style $style \
	--high_caps_path data/coco/coco_data_for_pos.txt \
	--low_caps_path data/senticap/factual_pos_train_val.txt \
	--low_caps_path data/flickr7k/factual_train_val.txt \
	--low_styles_train_path ${exp}/romantic_train_style.txt  \   
	--low_styles_val_path ${exp}/romantic_val_style.txt
